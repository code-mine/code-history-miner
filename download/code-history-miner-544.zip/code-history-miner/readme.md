Code history miner
==================

This is a server for project code history analysis and visualization.

To see command line options run 'bin/code-miner.sh' (or .bat) without arguments.

For any problems or questions you can [submit an issue on github](https://github.com/code-mine/code-history-miner/issues).
For more details visit http://codehistoryminer.com
